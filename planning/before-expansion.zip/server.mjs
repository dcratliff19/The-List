import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {randomBytes,createHash,createHmac,timingSafeEqual} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const token=()=>randomBytes(32).toString('base64url');
const digest=x=>createHash('sha256').update(x).digest();
const matches=(value,hash)=>typeof value==='string'&&timingSafeEqual(digest(value),hash);
export function createSignalingServer({now=Date.now,roomTtl=90*86400000,inviteTtl=900000,maxRooms=1000,turnUrls=process.env.TURN_URLS,turnSecret=process.env.TURN_SECRET,stateFile=process.env.STATE_FILE,iceServersUrl=process.env.ICE_SERVERS_URL}={}){
 const rooms=new Map(),rates=new Map();
 if(stateFile && fs.existsSync(stateFile)){
  const saved=JSON.parse(fs.readFileSync(stateFile,'utf8'));
  for(const [id,r] of saved.rooms??[]) if(r.expires>now()) rooms.set(id,{...r,host:Buffer.from(r.host,'base64'),invite:Buffer.from(r.invite,'base64'),guest:r.guest?Buffer.from(r.guest,'base64'):null,events:[]});
 }
 let dirty=false;
 const persist=()=>{if(!stateFile||!dirty)return;fs.mkdirSync(path.dirname(stateFile),{recursive:true});const records=[...rooms].map(([id,r])=>[id,{...r,host:r.host.toString('base64'),invite:r.invite.toString('base64'),guest:r.guest?.toString('base64')??null,events:[]}]);fs.writeFileSync(stateFile+'.tmp',JSON.stringify({version:1,rooms:records}),{mode:0o600});fs.renameSync(stateFile+'.tmp',stateFile);dirty=false;};
 const changed=()=>{dirty=true;persist();};
 const checkpoint=setInterval(persist,5000);checkpoint.unref();
 let iceCache=null,iceCacheUntil=0;

 const json=(res,status,data)=>{res.writeHead(status,{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff'});res.end(JSON.stringify(data));};
 const ice=async()=>{if(iceServersUrl){if(iceCache&&iceCacheUntil>now())return iceCache;const endpoint=new URL(iceServersUrl);if(endpoint.protocol!=='https:')throw new Error('ICE provider must use HTTPS');const response=await fetch(endpoint,{signal:AbortSignal.timeout(8000)});if(!response.ok)throw new Error('ICE provider unavailable');const data=await response.json();const values=Array.isArray(data)?data:data.iceServers;if(!Array.isArray(values)||!values.length)throw new Error('Invalid ICE provider response');iceCache=values;iceCacheUntil=now()+60000;return values;}const servers=[{urls:'stun:stun.l.google.com:19302'}];if(turnUrls&&turnSecret){const username=String(Math.floor(now()/1000)+3600)+':the-list';servers.push({urls:turnUrls.split(','),username,credential:createHmac('sha1',turnSecret).update(username).digest('base64')});}return servers;};
 const read=async req=>{let data='',size=0;for await(const chunk of req){size+=chunk.length;if(size>262144)throw new Error('Request too large');data+=chunk;}return data?JSON.parse(data):{};};
 const server=http.createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://localhost');const address=process.env.TRUST_PROXY==='true'?(String(req.headers['x-forwarded-for']||'').split(',').at(-1).trim()||req.socket.remoteAddress):req.socket.remoteAddress||'unknown';
   if(url.pathname==='/health')return json(res,200,{ok:true,service:'The List signaling',relayConfigured:!!((turnUrls&&turnSecret)||iceServersUrl)});
   let limit=rates.get(address);if(!limit||now()-limit.start>60000){limit={start:now(),count:0};rates.set(address,limit);}if(++limit.count>600)return json(res,429,{error:'Too many requests. Try again shortly.'});
   for(const [id,room]of rooms)if(room.expires<now())rooms.delete(id);
   if(req.method==='POST'&&url.pathname==='/rooms'){
    if(rooms.size>=maxRooms)return json(res,503,{error:'Server capacity reached'});
    const id=token(),host=token(),invite=token();
    rooms.set(id,{host:digest(host),invite:digest(invite),guest:null,inviteExpires:now()+inviteTtl,expires:now()+roomTtl,events:[],seq:0});
    changed();
    return json(res,201,{id,token:host,invite,expiresAt:now()+inviteTtl,iceServers:await ice()});
   }
   const parts=url.pathname.split('/');const room=rooms.get(parts[2]);if(parts[1]!=='rooms'||!room)return json(res,404,{error:'This sharing session has expired. Create a new invitation.'});
   const credential=(req.headers.authorization||'').replace(/^Bearer /,'');
   if(req.method==='POST'&&parts[3]==='join'){
    if(room.guest||room.inviteExpires<now()||!matches(credential,room.invite))return json(res,403,{error:'Invitation invalid, expired, or already used'});
    const guest=token();room.guest=digest(guest);room.expires=now()+roomTtl;changed();return json(res,200,{token:guest,iceServers:await ice()});
   }
   const role=matches(credential,room.host)?'host':room.guest&&matches(credential,room.guest)?'guest':null;
   if(!role)return json(res,403,{error:'Not authorized'});
   room.expires=now()+roomTtl;dirty=true;
   if(req.method==='GET'&&parts[3]==='ice')return json(res,200,{iceServers:await ice()});
   if(req.method==='GET'&&parts[3]==='events'){const after=Number(url.searchParams.get('after')||0);return json(res,200,{events:room.events.filter(e=>e.from!==role&&e.seq>after),sequence:room.seq,paired:!!room.guest});}
   if(req.method==='POST'&&parts[3]==='signals'){
    const data=await read(req);
    if(!['offer','answer','candidate','ready','bye'].includes(data.type))return json(res,400,{error:'Invalid signal'});
    room.events.push({...data,seq:++room.seq,from:role});if(room.events.length>512)room.events.shift();room.expires=now()+roomTtl;
    return json(res,200,{sequence:room.seq});
   }
   if(req.method==='DELETE'&&parts.length===3&&role==='host'){rooms.delete(parts[2]);changed();return json(res,200,{closed:true});}
   return json(res,404,{error:'Not found'});
  }catch{json(res,400,{error:'Invalid request'});}
 });
 server.requestTimeout=15000;server.headersTimeout=10000;
 const cleanup=setInterval(()=>{for(const [key,value]of rates)if(now()-value.start>60000)rates.delete(key);for(const [key,value]of rooms)if(value.expires<now())rooms.delete(key);},60000);cleanup.unref();server.on('close',()=>{clearInterval(cleanup);clearInterval(checkpoint);persist();});
 return server;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){const port=Number(process.env.PORT||5174);createSignalingServer().listen(port,process.env.HOST||'127.0.0.1',()=>console.log('The List signaling listening on port '+port));}

