import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:sqlite3/sqlite3.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as p;

typedef Json = Map<String, dynamic>;
const uuid = Uuid();

class Entry {
  final String id, project, kind;
  final Json fields;
  Entry(this.id, this.project, this.kind, this.fields);
  String text(String key) => fields[key]?.toString() ?? '';
  bool flag(String key) => fields[key] == true;
  List<String> get tags => parseTags(text('tags'));
  static List<String> parseTags(String text) {
    final seen = <String>{};
    return text
        .split(RegExp(r'[\s,]+'))
        .map((tag) => tag.replaceFirst(RegExp(r'^#+'), ''))
        .where((tag) => tag.isNotEmpty && seen.add(tag.toLowerCase()))
        .toList();
  }

  static const currencies = ['USD', 'EUR', 'GBP', 'CAD', 'AUD'];
  static int? parsePrice(String value) {
    final text = value.trim();
    if (text.isEmpty) return null;
    if (!RegExp(r'^\d{1,9}(\.\d{1,2})?$').hasMatch(text)) {
      throw const FormatException(
        'Enter a positive price with up to two decimal places, or leave blank.',
      );
    }
    final parts = text.split('.');
    return int.parse(parts[0]) * 100 +
        int.parse(parts.length == 1 ? '0' : parts[1].padRight(2, '0'));
  }

  static String amount(int cents) =>
      '${cents ~/ 100}.${(cents % 100).toString().padLeft(2, '0')}';
  int? get priceMinor => parsePrice(text('price'));
  String get currency =>
      currencies.contains(text('currency')) ? text('currency') : 'USD';
  String get priceLabel =>
      priceMinor == null ? '' : '$currency ${amount(priceMinor!)}';
  String get title => text('title');
  bool get deleted => flag('deleted');
  Json toJson() => {
    'id': id,
    'project': project,
    'kind': kind,
    'fields': fields,
  };
}

class Store extends ChangeNotifier {
  final Database db;
  final Directory directory;
  late String device;
  int clock = 0;
  Store(this.directory, {Database? database})
    : db = database ?? sqlite3.open(p.join(directory.path, 'the-list.sqlite')) {
    db.execute('PRAGMA journal_mode=WAL');
    db.execute('PRAGMA foreign_keys=ON');
    db.execute(
      'CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY,value TEXT NOT NULL)',
    );
    db.execute(
      'CREATE TABLE IF NOT EXISTS operations (id TEXT PRIMARY KEY,project TEXT NOT NULL,entity TEXT NOT NULL,kind TEXT NOT NULL,counter INTEGER NOT NULL,device TEXT NOT NULL,fields TEXT NOT NULL)',
    );
    db.execute('CREATE INDEX IF NOT EXISTS project_ops ON operations(project)');
    db.execute(
      'CREATE TABLE IF NOT EXISTS entities (id TEXT PRIMARY KEY,project TEXT NOT NULL,kind TEXT NOT NULL,fields TEXT NOT NULL,stamps TEXT NOT NULL)',
    );
    db.execute('PRAGMA user_version=1');
    device = setting('device') ?? uuid.v4();
    setSetting('device', device);
    clock =
        (db.select('SELECT MAX(counter) AS n FROM operations').first['n']
            as int?) ??
        0;
  }
  String? setting(String key) {
    final rows = db.select('SELECT value FROM settings WHERE key=?', [key]);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  void setSetting(String key, String value) =>
      db.execute('INSERT OR REPLACE INTO settings VALUES(?,?)', [key, value]);
  Entry _entry(Row r) => Entry(
    r['id'] as String,
    r['project'] as String,
    r['kind'] as String,
    jsonDecode(r['fields'] as String) as Json,
  );
  List<Entry> get entries =>
      db.select('SELECT * FROM entities').map(_entry).toList();
  Entry? get(String id) {
    final rows = db.select('SELECT * FROM entities WHERE id=?', [id]);
    return rows.isEmpty ? null : _entry(rows.first);
  }

  List<Entry> get projects =>
      entries.where((e) => e.kind == 'project' && !e.deleted).toList()
        ..sort(_recent);
  Map<String, int> projectTotals(String project) {
    final totals = <String, int>{};
    for (final entry in items(project).where((e) => e.kind == 'link')) {
      final cents = entry.priceMinor;
      if (cents != null) {
        totals.update(
          entry.currency,
          (total) => total + cents,
          ifAbsent: () => cents,
        );
      }
    }
    return totals;
  }

  List<Entry> items(String project) =>
      entries
          .where(
            (e) => e.project == project && e.kind != 'project' && !e.deleted,
          )
          .toList()
        ..sort(_recent);
  static int _recent(Entry a, Entry b) {
    final date = b.text('created').compareTo(a.text('created'));
    return date != 0 ? date : a.id.compareTo(b.id);
  }

  String create(String kind, String project, Json fields) {
    final id = uuid.v4();
    change(id, kind == 'project' ? id : project, kind, {
      'created': DateTime.now().toUtc().toIso8601String(),
      ...fields,
    });
    return id;
  }

  void update(Entry e, Json fields) {
    final changes = Map<String, dynamic>.fromEntries(
      fields.entries.where(
        (f) => jsonEncode(e.fields[f.key]) != jsonEncode(f.value),
      ),
    );
    if (changes.isNotEmpty) change(e.id, e.project, e.kind, changes);
  }

  void change(String id, String project, String kind, Json fields) => apply([
    {
      'id': uuid.v4(),
      'entity': id,
      'project': project,
      'kind': kind,
      'counter': ++clock,
      'device': device,
      'fields': fields,
    },
  ]);
  static void validate(Json op) {
    if (![
          'project',
          'link',
          'note',
          'photo',
          'reminder',
        ].contains(op['kind']) ||
        op['id'] is! String ||
        op['entity'] is! String ||
        op['project'] is! String ||
        op['device'] is! String ||
        op['counter'] is! int ||
        op['fields'] is! Map) {
      throw const FormatException('Invalid project data');
    }
    if ((op['counter'] as int) < 0 ||
        (op['counter'] as int) > 9007199254740000 ||
        jsonEncode(op).length > 262144) {
      throw const FormatException('Project data exceeds limits');
    }
    for (final key in ['id', 'entity', 'project', 'device']) {
      if ((op[key] as String).isEmpty || (op[key] as String).length > 128) {
        throw const FormatException('Invalid identity');
      }
    }
    if (op['kind'] == 'project' && op['entity'] != op['project']) {
      throw const FormatException('Invalid project identity');
    }
    const strings = {
      'title',
      'body',
      'description',
      'url',
      'tags',
      'photo',
      'cover',
      'due',
      'zone',
      'target',
      'created',
      'label',
      'previewTitle',
      'previewDescription',
      'previewError',
      'previewStatus',
      'boardStatus',
      'price',
      'currency',
    };
    const flags = {'deleted', 'archived', 'favorite', 'example', 'done'};
    (op['fields'] as Map).forEach((key, value) {
      if (key == 'price') {
        if (value is! String) throw const FormatException('Invalid price');
        Entry.parsePrice(value);
      }
      if (key == 'currency' && !Entry.currencies.contains(value)) {
        throw const FormatException('Invalid currency');
      }
      if (strings.contains(key)) {
        if (value is! String || value.length > 50000) {
          throw const FormatException('Invalid text field');
        }
      } else if (flags.contains(key)) {
        if (value is! bool) throw const FormatException('Invalid flag');
      } else if (key == 'color') {
        if (value is! int || value < 0 || value > 0xffffffff) {
          throw const FormatException('Invalid color');
        }
      } else {
        throw const FormatException('Unknown project field');
      }
      if ((key == 'photo' || key == 'cover') &&
          value != '' &&
          !RegExp(r'^[a-f0-9]{64}$').hasMatch(value as String)) {
        throw const FormatException('Invalid photo reference');
      }
    });
  }

  void apply(List<Json> operations, {String? scope}) {
    for (final op in operations) {
      validate(op);
      if (scope != null && op['project'] != scope) {
        throw const FormatException('Project boundary mismatch');
      }
    }
    db.execute('BEGIN IMMEDIATE');
    try {
      for (final op in operations) {
        if (db.select('SELECT id FROM operations WHERE id=?', [
          op['id'],
        ]).isNotEmpty) {
          continue;
        }
        final existing = db.select('SELECT * FROM entities WHERE id=?', [
          op['entity'],
        ]);
        if (existing.isNotEmpty &&
            (existing.first['project'] != op['project'] ||
                existing.first['kind'] != op['kind'])) {
          throw const FormatException('Entity identity mismatch');
        }
        final fields = existing.isEmpty
            ? <String, dynamic>{}
            : jsonDecode(existing.first['fields'] as String) as Json;
        final stamps = existing.isEmpty
            ? <String, dynamic>{}
            : jsonDecode(existing.first['stamps'] as String) as Json;
        final stamp = [op['counter'], op['device'], op['id']];
        (op['fields'] as Map).forEach((key, value) {
          final old = stamps[key] as List?;
          if (old == null || compareStamp(stamp, old) > 0) {
            fields[key as String] = value;
            stamps[key] = stamp;
          }
        });
        db.execute('INSERT INTO operations VALUES(?,?,?,?,?,?,?)', [
          op['id'],
          op['project'],
          op['entity'],
          op['kind'],
          op['counter'],
          op['device'],
          jsonEncode(op['fields']),
        ]);
        db.execute('INSERT OR REPLACE INTO entities VALUES(?,?,?,?,?)', [
          op['entity'],
          op['project'],
          op['kind'],
          jsonEncode(fields),
          jsonEncode(stamps),
        ]);
        if ((op['counter'] as int) > clock) clock = op['counter'] as int;
      }
      db.execute('COMMIT');
    } catch (_) {
      db.execute('ROLLBACK');
      rethrow;
    }
    notifyListeners();
  }

  static int compareStamp(List a, List b) {
    final n = (a[0] as int).compareTo(b[0] as int);
    if (n != 0) return n;
    final d = (a[1] as String).compareTo(b[1] as String);
    return d != 0 ? d : (a[2] as String).compareTo(b[2] as String);
  }

  Json _operation(Row r) => {
    'id': r['id'],
    'project': r['project'],
    'entity': r['entity'],
    'kind': r['kind'],
    'counter': r['counter'],
    'device': r['device'],
    'fields': jsonDecode(r['fields'] as String),
  };
  List<Json> operations(String project, {bool includeReminders = false}) => db
      .select(
        'SELECT * FROM operations WHERE project=? ORDER BY counter,device,id',
        [project],
      )
      .where((r) => includeReminders || r['kind'] != 'reminder')
      .map(_operation)
      .toList();
  List<Json> history(String id) => db
      .select(
        'SELECT * FROM operations WHERE entity=? ORDER BY counter DESC,device DESC',
        [id],
      )
      .map(
        (r) => {
          'device': r['device'],
          'fields': jsonDecode(r['fields'] as String),
        },
      )
      .toList();
  File blob(String hash) {
    if (!RegExp(r'^[a-f0-9]{64}$').hasMatch(hash)) {
      throw const FormatException('Invalid attachment hash');
    }
    return File(p.join(directory.path, 'photos', '$hash.jpg'));
  }

  Future<void> exportTo(File file) async =>
      file.writeAsString(await exportData(), flush: true);
  Future<String> exportData() async {
    final ops = db.select('SELECT * FROM operations').map(_operation).toList();
    final photos = <String, String>{};
    var total = 0;
    for (final e in entries) {
      for (final key in ['photo', 'cover']) {
        final hash = e.text(key);
        if (hash.isNotEmpty &&
            !photos.containsKey(hash) &&
            blob(hash).existsSync()) {
          total += await blob(hash).length();
          if (total > 100 * 1024 * 1024) {
            throw const FormatException(
              'This portable backup exceeds 100 MB of photos. Copy the local workspace folder for a complete backup.',
            );
          }
          photos[hash] = base64Encode(await blob(hash).readAsBytes());
        }
      }
    }
    return jsonEncode({
      'format': 'the-list',
      'version': 1,
      'operations': ops,
      'photos': photos,
    });
  }

  Future<void> importFrom(File file) async {
    if (await file.length() > 200 * 1024 * 1024) {
      throw const FormatException('Backup exceeds 200 MB');
    }
    final data = jsonDecode(await file.readAsString()) as Json;
    if (data['format'] != 'the-list' || data['version'] != 1) {
      throw const FormatException('Unsupported backup format');
    }
    final ops = (data['operations'] as List)
        .map((o) => Map<String, dynamic>.from(o as Map))
        .toList();
    for (final op in ops) {
      validate(op);
    }
    final photos = Map<String, dynamic>.from(data['photos'] as Map);
    for (final entry in photos.entries) {
      blob(entry.key);
      final bytes = base64Decode(entry.value as String);
      if (bytes.length > 20 * 1024 * 1024 ||
          sha256.convert(bytes).toString() != entry.key) {
        throw const FormatException('Photo integrity check failed');
      }
    }
    for (final entry in photos.entries) {
      final f = blob(entry.key);
      await f.parent.create(recursive: true);
      await f.writeAsBytes(base64Decode(entry.value as String), flush: true);
    }
    apply(ops);
  }

  void touch() => notifyListeners();
  @override
  void dispose() {
    db.close();
    super.dispose();
  }
}
